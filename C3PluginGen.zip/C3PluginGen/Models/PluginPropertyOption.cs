﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class PluginPropertyOption : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public string Type { get; set; }
        public string Value { get; set; }
    }

    public static class PluginPropertyOptionType
    {
        public const string InitialValue = "initialValue";
        public const string MinValue = "minValue";
        public const string MaxValue = "maxValue";
        public const string DragSpeedMultiplier = "dragSpeedMultiplier";
        public const string LinkCallback = "linkCallback";
        public const string CallbackType = "callbackType";
        public const string Items = "items";
    }

    public static class CallbackType
    {
        public const string ForEachInstance = "for-each-instance";
        public const string OnceForType = "once-for-type";
    }
}
