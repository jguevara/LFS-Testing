﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Aces : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public List<Actions> Actions { get; set; }
        public List<Condition> Conditions { get; set; }
        public List<Expression> Expressions { get; set; }

        public Aces()
        {
            Actions = new List<Actions>();
            Conditions = new List<Condition>();
            Expressions = new List<Expression>();
        }
    }

    public abstract class AceBase
    {
        //Each category key is the category ID.This is not displayed in the editor; the string to display
        //is looked up in the language file.
        public string CategoryID { get; set; }
        //When defining ACEs, category IDs are used rather than category names. The "aceCategories" key defines the displayed name of each category
        public string CategoryName { get; set; }
        //A string specifying a unique ID for the ACE. This is used in the language file. 
        //By convention this is lowercase with dashes for separators, e.g. "my-condition".
        public string ID { get; set; }
        public string Name { get; set; }
        //If you are porting a Construct 2 addon to Construct 3, put the corresponding numerical ID that the 
        //Construct 2 addon used here. This allows Construct 3 to import Construct 2 projects using your addon.
        public string C2ID { get; set; }
    }
}
