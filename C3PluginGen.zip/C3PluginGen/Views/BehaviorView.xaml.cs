﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for BehaviorView.xaml
    /// </summary>
    public partial class BehaviorView : UserControl
    {
        public Behavior Behavior { get; set; }

        public BehaviorView()
        {
            Behavior = new Behavior();

            InitializeComponent();

            EventBus.Hub.Subscribe<AddonNameChangedEvent>(AddonNameChange);
            EventBus.Hub.Subscribe<BehaviorExportEvent>(BuildBehavior);
        }

        private void BuildBehavior(BehaviorExportEvent obj)
        {
            Behavior.BehaviorClass = BehaviorClass.Text;

            Behavior.IsDeprecated = IsDeprecated.IsChecked != null && (IsDeprecated.IsChecked.Value);
            Behavior.CanBeBundled = CanBeBundled.IsChecked != null && (CanBeBundled.IsChecked.Value);
            Behavior.IsOnlyOneAllowed = IsOnlyOneAllowed.IsChecked != null && (IsOnlyOneAllowed.IsChecked.Value);

            Behavior.ShowIsDeprecated = DisplayIsDeprecated.IsChecked != null && (DisplayIsDeprecated.IsChecked.Value);
            Behavior.ShowCanBeBundled = DisplayCanBeBundled.IsChecked != null && (DisplayCanBeBundled.IsChecked.Value);
            Behavior.ShowIsOnlyOneAllowed = DisplayIsOnlyOneAllowed.IsChecked != null && (DisplayIsOnlyOneAllowed.IsChecked.Value);
        }

        private void AddonNameChange(AddonNameChangedEvent obj)
        {
            BehaviorClass.Text = obj.Name.Replace(" ", string.Empty);
        }
    }
}
