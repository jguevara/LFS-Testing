﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TinyMessenger;

namespace C3PluginGen.Framework
{
    public class EventBus : Singleton<EventBus>
    {
        private ITinyMessengerHub hub = new TinyMessengerHub();
        public static ITinyMessengerHub Hub => EventBus.Instance.hub;
    }

    //generic message
    public class EventMessage<T> : GenericTinyMessage<T>
    {
        public EventMessage(object caller, object sender, T content) : base(sender, content)
        {
        }
    }

    public class AddonTypeChangedEvent : EventMessage<string>
    {
        public string Type;

        public AddonTypeChangedEvent(object sender, string content) : base(typeof(AddonTypeChangedEvent), sender, content)
        {
            Type = content;
        }
    }

    public class AddonNameChangedEvent : EventMessage<string>
    {
        public string Name;

        public AddonNameChangedEvent(object sender, string content) : base(typeof(AddonNameChangedEvent), sender, content)
        {
            Name = content;
        }
    }

    public class ApplicationErrorEvent : EventMessage<string>
    {
        public string Message;
        public ApplicationErrorEvent(object sender, string content) : base(typeof(ApplicationErrorEvent), sender, content)
        {
            Message = content;
        }
    }

    public class AddonExportEvent : TinyMessageBase 
    {
        public AddonExportEvent(object sender) : base(sender)
        {
        }
    }

    public class PluginExportEvent : TinyMessageBase
    {
        public PluginExportEvent(object sender) : base(sender)
        {
        }
    }

    public class BehaviorExportEvent : TinyMessageBase
    {
        public BehaviorExportEvent(object sender) : base(sender)
        {
        }
    }
}
