﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class PluginProperty : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public string Type { get; set; }
        //A string of the ID for the property. This is used in the language file to identify related strings.
        public string PropertyId { get; set; }
        public List<PluginPropertyOption> Options { get; set; }
        //the name of the property, which appears to the left of the field
        public string Name { get; set; }
        //the property description, which appears in the footer of the Properties Bar
        public string Description { get; set; }
        //The "link" property type needs an extra "link-text" key to set the text of the clickable link
        public string LinkText { get; set; }
        //The "combo" property type needs an extra "items" key to set the visible name of each item. 
        //Each key underneath this should be the ID of the combo item, and its value the name to use
        public Dictionary<string, string> ItemsNames { get; set; }

        //ctor
        public PluginProperty()
        {
            Options = new List<PluginPropertyOption>();
            ItemsNames = new Dictionary<string, string>();
        }

        public PluginProperty WithOption(string type, string value)
        {
            var opt = new PluginPropertyOption
            {
                Type = type,
                Value = value
            };

            Options.Add(opt);

            return this;
        }

        public PluginProperty WithItem(string key, string value)
        {
            ItemsNames.Add(key, value);
            return this;
        }

        public PluginProperty WithLinkText(string text)
        {
            LinkText = text;
            return this;
        }

        public static PluginProperty Create(string id, string name, string desc, string type)
        {
            return new PluginProperty
            {
                Description = desc,
                Name = name,
                PropertyId = id,
                Type = type
            };
        }

        public override bool Equals(object obj)
        {
            try
            {
                return this.PropertyId == ((PluginProperty) obj)?.PropertyId;
            }
            catch
            {
                return false;
            }

        }

        public override int GetHashCode()
        {
            return this.PropertyId.GetHashCode();
        }
    }

    public static class PluginPropertyType
    {
        public const string Integer = "integer";
        public const string Float = "float";
        public const string Percent = "percent";
        public const string Text = "text";
        public const string LongText = "longtext";
        public const string Check = "check";
        public const string Font = "font";
        public const string Combo = "combo";
        public const string Color = "color";
        public const string Group = "group";
        public const string Link = "link";
    }
}
