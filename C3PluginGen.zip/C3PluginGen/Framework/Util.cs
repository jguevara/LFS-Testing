﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace C3PluginGen.Framework
{
    public class Util
    {
        public static string BoolStr(bool value)
        {
            return value ? "true" : "false";
        }

        public static string FormatJson(string json)
        {
            return JValue.Parse(json).ToString(Formatting.Indented);
        }
    }
}
