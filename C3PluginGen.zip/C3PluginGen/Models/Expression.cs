﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Expression : AceBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        //The name of the function in the runtime script for this ACE. Note for expressions, use expressionName instead, 
        //which also defines the name typed by the user in expressions.
        public string ExpressionName { get; set; }
        //One of "number", "string", "any". The runtime function must return the corresponding type, and "any" must still return either a number or a string
        public string ReturnType { get; set; }
        //Set to true to deprecate the ACE. This hides it in the editor, but allows existing projects to continue using it.
        public bool IsDeprecated { get; set; }
        //Set to true to highlight the ACE in the condition/action/expression picker dialogs. This should only be used
        //for the most regularly used ACEs, to help users pick them out from the list easily.
        public bool Highlight { get; set; }
        //An array of parameter definitions. See the section below on parameters. This can be omitted if the ACE does not use any parameters.
        public List<AceParameter> Parameters { get; set; }
        //If true, Construct 3 will allow the user to enter any number of parameters beyond those defined. In other words the parameters 
        //(if any) listed in "params" are required, but this flag enables adding further "any" type parameters beyond the end.
        public bool IsVariadicParameters { get; set; }


        //he description that appears in the expressions dictionary, which lists all available expressions.
        public string Description { get; set; }
        //the translated name of the expression name. In the en-US file, this should simply match the expression name from the expression definition. 
        //This key mainly exists so it can be changed in other languages, making it possible to translate expressions in some contexts. 
        //Note when actually typing an expression the non-translated expression name must always be used.
        public string TranslatedName { get; set; }

        public Expression()
        {
            Parameters = new List<AceParameter>();
        }

        public override bool Equals(object obj)
        {
            try
            {
                return this.ID == ((Expression)obj)?.ID;
            }
            catch
            {
                return false;
            }

        }

        public override int GetHashCode()
        {
            return this.ID.GetHashCode();
        }
    }

    public abstract class ExpressionReturnType
    {
        public const string Number = "number";
        public const string String = "string";
        public const string Any = "any";
    }
}
