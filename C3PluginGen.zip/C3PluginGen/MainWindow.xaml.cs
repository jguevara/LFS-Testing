﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Views;
using MahApps.Metro.Controls;
using ToastNotifications;
using ToastNotifications.Lifetime;
using ToastNotifications.Messages;
using ToastNotifications.Position;

namespace C3PluginGen
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        Notifier toast = new Notifier(cfg =>
        {
            cfg.PositionProvider = new WindowPositionProvider(
                parentWindow: Application.Current.MainWindow,
                corner: Corner.TopRight,
                offsetX: 10,
                offsetY: 10);

            cfg.LifetimeSupervisor = new TimeAndCountBasedLifetimeSupervisor(
                notificationLifetime: TimeSpan.FromSeconds(3),
                maximumNotificationCount: MaximumNotificationCount.FromCount(5));

            cfg.Dispatcher = Application.Current.Dispatcher;
        });

        public MainWindow()
        {
            InitializeComponent();
            EventBus.Hub.Subscribe<AddonTypeChangedEvent>(AddonTypeChange);
            EventBus.Hub.Subscribe<ApplicationErrorEvent>(ApplicationError);

            //link up export
            Export.Main = this;
        }

        private void ApplicationError(ApplicationErrorEvent obj)
        {
            toast.ShowError(obj.Message);
        }

        private void AddonTypeChange(AddonTypeChangedEvent obj)
        {
            var pluginVisible = obj.Type.Equals("Plugin");
            var behaviorVisible = obj.Type.Equals("Behavior");

            PluginTab.Visibility = pluginVisible ? Visibility.Visible : Visibility.Collapsed;
            BehaviorTab.Visibility = behaviorVisible ? Visibility.Visible : Visibility.Collapsed;
        }

    }
}
