﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class AddonJsonGenerator : IGenerator<Addon>
    {
        public string Generate(Addon type)
        {
            var template = $@"
            {{
                ""is-c3-addon"" : {Util.BoolStr(type.IsC3Addon)},
                ""type"": ""{type.Type}"",
	            ""name"": ""{type.PluginName}"",
	            ""id"": ""{type.PluginID}"",
	            ""version"": ""{type.Version}"",
	            ""author"": ""{type.Author}"",
	            ""website"": ""{type.Website}"",
	            ""documentation"": ""{type.Documentation}"",
	            ""description"": ""{type.Description}"",
		        ""editor-scripts"": [ ""{type.Type}.js"", ""type.js"", ""instance.js"" ],
                ""file-list"": [ 
                    {GenerateFileListString(type)} 
                ],
                ""stylesheets"":[ ]
            }}
            ";

            return Util.FormatJson(template);
        }

        private string GenerateFileListString(Addon type)
        {
            return string.Join(",\n\t\t\t\t\t", type.FileList.Select(x => $"\"{x}\""));
        }

        private string GenerateStylesheetString(Addon type)
        {
            throw new NotImplementedException();
        }
    }

}
