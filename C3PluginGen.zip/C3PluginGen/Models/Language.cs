﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Language : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public string LanguageTag { get; set; }
        public Addon Addon { get; set; }
        public Plugin Plugin { get; set; }
        public Behavior Behavior { get; set; }
        public Aces Aces { get; set; }

        public Language()
        {
            LanguageTag = "en-US";
        }
    }
}
