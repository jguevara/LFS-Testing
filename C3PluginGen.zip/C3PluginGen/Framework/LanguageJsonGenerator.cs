﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class LanguageJsonGenerator : IGenerator<Language>
    {
        public string Generate(Language type)
        {
            var template = $@"
            {{
                ""languageTag"" : ""{type.LanguageTag}"",
                ""fileDescription"" : ""Strings for {type.Addon.PluginName}"",
                ""text"" : {{
                    ""{type.Addon.Type}s"" : {{
                        ""{type.Addon.PluginID}"" : {{
                            ""name"" : ""{type.Addon.PluginName}"",
                            ""description"" : ""{type.Addon.Description}"",
                            ""help-url"" : ""{type.Addon.Documentation}"",
                            ""properties"" : {{
                                {GeneratePropertyStrings(type)}
                            }},
                            ""aceCategories"" : {{
                                {GenerateAceCategoryStrings(type.Aces)}
                            }},
                            ""conditions"" : {{
                                {GenerateConditionsStrings(type.Aces.Conditions)}
                            }},
                            ""actions"" : {{
                                {GenerateActionsStrings(type.Aces.Actions)}
                            }},
                            ""expressions"" : {{
                                {GenerateExpressionsStrings(type.Aces.Expressions)}
                            }}
                        }}
                    }}
                }}
            }}
            ";

           return Util.FormatJson(template);
        }

        public string GeneratePropertyStrings(Language type)
        {
            switch (type.Addon.Type)
            {
                case "Plugin":
                    return GeneratePropertyStrings(type.Plugin);
                case "Beahvior":
                    return GeneratePropertyStrings(type.Behavior);
                default:
                    throw new Exception("Invalid Addon Type");
            }
        }

        private string GeneratePropertyStrings(Plugin plugin)
        {
            List<string> props = new List<string>();

            foreach (var pluginProperty in plugin.Properties)
            {
                var str = $@"
                    ""{pluginProperty.PropertyId}"" : {{
                        ""name"" : ""{pluginProperty.Name}"",
                        ""description"" : ""{pluginProperty.Description}""
                    }}
                    ";

                if (pluginProperty.Type == PluginPropertyType.Combo)
                {
                    var items = pluginProperty.ItemsNames.Select(x => $"\"{x.Key}\" : \"{x.Value}\"");
                    var itemString = string.Join(",", items);

                    str = $@"
                        ""{pluginProperty.PropertyId}"" : {{
                            ""name"" : ""{pluginProperty.Name}"",
                            ""description"" : ""{pluginProperty.Description}"",
                            ""items"" : {{
                                {itemString}
                            }}
                        }}
                        ";
                }

                if (pluginProperty.Type == PluginPropertyType.Link)
                {
                    str = $@"
                        ""{pluginProperty.PropertyId}"" : {{
                            ""name"" : ""{pluginProperty.Name}"",
                            ""description"" : ""{pluginProperty.Description}"",
                            ""link-text"" : ""{pluginProperty.LinkText}""
                        }}
                        ";
                }

                props.Add(str);
            }

            return string.Join(",\n", props);
        }

        private string GeneratePropertyStrings(Behavior plugin)
        {
            List<string> props = new List<string>();

            foreach (var pluginProperty in plugin.Properties)
            {
                var str = $@"
                    ""{pluginProperty.PropertyId}"" : {{
                        ""name"" : ""{pluginProperty.Name}"",
                        ""description"" : ""{pluginProperty.Description}""
                    }}
                    ";

                if (pluginProperty.Type == PluginPropertyType.Combo)
                {
                    var items = pluginProperty.ItemsNames.Select(x => $"\"{x.Key}\" : \"{x.Value}\"");
                    var itemString = string.Join(",", items);

                    str = $@"
                        ""{pluginProperty.PropertyId}"" : {{
                            ""name"" : ""{pluginProperty.Name}"",
                            ""description"" : ""{pluginProperty.Description}"",
                            ""items"" : {{
                                {itemString}
                            }}
                        }}
                        ";
                }

                if (pluginProperty.Type == PluginPropertyType.Link)
                {
                    str = $@"
                        ""{pluginProperty.PropertyId}"" : {{
                            ""name"" : ""{pluginProperty.Name}"",
                            ""description"" : ""{pluginProperty.Description}"",
                            ""link-text"" : ""{pluginProperty.LinkText}""
                        }}
                        ";
                }

                props.Add(str);
            }

            return string.Join(",\n", props);
        }

        private string GenerateAceCategoryStrings(Aces aces)
        {
            Dictionary<string, string> keyValue = new Dictionary<string, string>();

            foreach (var exp in aces.Expressions)
            {
                //keyValue.Add(exp.CategoryID, exp.CategoryName);
                keyValue[exp.CategoryID] = exp.CategoryName;
            }

            foreach (var act in aces.Actions)
            {
                //keyValue.Add(act.CategoryID, act.CategoryName);
                keyValue[act.CategoryID] = act.CategoryName;
            }

            foreach (var con in aces.Conditions)
            {
                //keyValue.Add(con.CategoryID, con.CategoryName);
                keyValue[con.CategoryID] = con.CategoryName;
            }

            return string.Join(",", keyValue.Select(x =>  $"\"{x.Key}\" : \"{x.Value}\""));
        }

        private string GenerateConditionsStrings(IEnumerable<Condition> conditions)
        {
            List<string> cond = new List<string>();
            foreach (var condition in conditions)
            {
                var str = $@"
                    ""{condition.ID}"" : {{
                        ""list-name"" : ""{condition.ListName}"",
                        ""display-text"" : ""{condition.DisplayText}"",
                        ""description"" : ""{condition.Description}"",
                        ""params"" : {{
                            {GenerateParamString(condition.Parameters)}
                        }}
                    }}
                ";

                cond.Add(str);
            }

            return string.Join(",", cond);
        }

        private string GenerateActionsStrings(IEnumerable<Actions> actions)
        {
            List<string> act = new List<string>();
            foreach (var action in actions)
            {
                var str = $@"
                    ""{action.ID}"" : {{
                        ""list-name"" : ""{action.ListName}"",
                        ""display-text"" : ""{action.DisplayText}"",
                        ""description"" : ""{action.Description}"",
                        ""params"" : {{
                            {GenerateParamString(action.Parameters)}
                        }}
                    }}
                ";

                act.Add(str);
            }

            return string.Join(",", act);
        }

        private string GenerateExpressionsStrings(IEnumerable<Expression> expressions)
        {
            List<string> exp = new List<string>();
            foreach (var expression in expressions)
            {
                var str = $@"
                    ""{expression.ID}"" : {{
                        ""description"" : ""{expression.Description}"",
                        ""translated-name"" : ""{expression.TranslatedName}"",
                        ""params"" : {{
                            {GenerateParamString(expression.Parameters)}
                        }}
                    }}
                ";

                exp.Add(str);
            }

            return string.Join(", ", exp);
        }

        private string GenerateParamString(IEnumerable<AceParameter> parameters)
        {
            List<string> param = new List<string>();

            foreach (var aceParameter in parameters)
            {
                var str = $@"
                ""{aceParameter.ID}"" : {{
                    ""name"" : ""{aceParameter.Name}"",
                    ""desc"" : ""{aceParameter.Description}""
                }}
                ";

                if (aceParameter.Type == AceParameterType.Combo)
                {
                    var items = aceParameter.ItemsNames.Select(x => $"\"{x.Key}\" : \"{x.Value}\"");
                    var itemString = string.Join(", ", items);

                    str = $@"
                    ""{aceParameter.ID}"" : {{
                        ""name"" : ""{aceParameter.Name}"",
                        ""desc"" : ""{aceParameter.Description}"",
                        ""items"" : {{
                            {itemString}
                        }}
                    }}
                    ";
                }

                param.Add(str);
            }

            return string.Join(",", param);
        }
    }
}
