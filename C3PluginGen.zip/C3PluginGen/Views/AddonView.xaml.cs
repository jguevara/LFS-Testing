using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for AddonView.xaml
    /// </summary>
    public partial class AddonView : UserControl
    {
        public Addon Addon { get; set; }

        public AddonView()
        {
            Addon = new Addon();

            InitializeComponent();

            FieldInfo[] properties = typeof(AddonType).GetFields();
            AddonType.ItemsSource = properties.Select(x => x.Name);

            //select plugin
            AddonType.SelectedIndex = 0;

            EventBus.Hub.Subscribe<AddonExportEvent>(BuildAddonModel);
        }

        private void BuildAddonModel(AddonExportEvent obj)
        {
            Addon.PluginID = AddonID.Text;
            Addon.PluginName = AddonName.Text;
            Addon.Description = Description.Text;
            Addon.Type = AddonType.Text;
            Addon.Author = Author.Text;
            Addon.IsC3Addon = true;
            Addon.Website = Website.Text;
            Addon.Documentation = DocumentationUrl.Text;
            Addon.Version = AddonVersion.Text;
            Addon.PluginCatgeory = AddonCategory.Text;
        }

        private void AddonType_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;

            var pluginType = e.AddedItems[0].ToString();
            EventBus.Hub.Publish(new AddonTypeChangedEvent(this, pluginType));
        }

        private void AddonName_OnLostFocus(object sender, RoutedEventArgs e)
        {
            var addonName = AddonName.Text;
            EventBus.Hub.Publish(new AddonNameChangedEvent(this, addonName));
        }
    }
}
