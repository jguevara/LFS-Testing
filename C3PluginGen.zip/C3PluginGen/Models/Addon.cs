﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Addon : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        //Boolean set to true. This is used by Construct 3 to identify valid addons
        public bool IsC3Addon { get; set; }
        //One of "plugin", "behavior", "effect" or "theme", indicating the kind of addon this is.
        public string Type { get; set; }
        //The name of the addon, in English.
        public string PluginName { get; set; }
        //The unique ID of the addon. This must not be used by any other addon ever published for Construct 3, 
        //and must never change after you first publish your addon. (The name is the only visible identifier of 
        //the addon in the Construct 3 editor, so that can be changed any time, but the ID must always be the same.) 
        //To ensure it is unique, it is recommended to use a vendor-addon format, e.g. mycompany-superaddon.
        //It must match the ID set in plugin.js.
        public string PluginID { get; set; }
        //A string specifying the addon version in four parts (major, minor, patch, revision). Be sure to update this 
        //when releasing updates to your addon. It must match the version set in plugin.js/behavior.js.
        public string Version { get; set; }
        //A string identifying the author of the addon.
        public string Author { get; set; }
        public string PluginCatgeory { get; set; }
        //A string of a URL to the author's website. It is recommended to provide updates to 
        //the addon at this URL if any become available. The website should use HTTPS.
        public string Website { get; set; }
        //A string of a brief description of what the addon does, displayed when prompting the user 
        //to install the addon.
        public string Description { get; set; }
        //A string of a URL to the online documentation for the addon. It is important to provide 
        //documentation for your addon to be useful to users
        public string Documentation { get; set; }
        //For plugins and behaviors only. An array of script files in the addon package to load in the editor. 
        //It is recommended to leave this at the default unless you have large editor dependency scripts, or if 
        //you want to minify your addon in to a single script. Note themes do not use editor scripts.
        public List<string> EditorScripts { get; set; }
        //For themes only. An array of CSS files in the addon package to apply to the document. 
        //These are the CSS files that define the theme's appearance.
        public List<string> CssFiles { get; set; }
        //When using developer mode addons, you must also provide a full list of all the files in your addon in addon.json. 
        //This is done by adding an array of paths under a new "file-list"
        public bool DevelopmentMode { get; set; }
        public List<string> FileList { get; set; }

        public Addon()
        {
            EditorScripts = new List<string>();
            CssFiles = new List<string>();
            FileList = new List<string>
            {
                "c2runtime/runtime.js",
                "lang/en-US.json",
                "aces.json",
                "addon.json",
                "icon.png",
                "instance.js",
                $"{Type}.js",
                "type.js"
            };
        }

        public void AddEdiotrScript(string script)
        {
            EditorScripts.Add(script);
        }

        public void AddFileDependency(string file)
        {
            FileList.Add(file);
        }

        public void AddCssFile(string css)
        {
            CssFiles.Add(css);
        }
    }

    public static class AddonType
    {
        public const string Plugin = "plugin";
        public const string Behavior = "behavior";
        //public const string Effect = "effect";
        //public const string Theme = "theme";
    }
}
