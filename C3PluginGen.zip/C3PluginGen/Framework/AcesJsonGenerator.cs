﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class AcesJsonGenerator : IGenerator<Aces>
    {
        public string Generate(Aces ace)
        {
            List<string> aceData = new List<string>();

            foreach (var cat in GetCategroy(ace))
            {
                aceData.Add(GenerateCategoryJson(cat, ace));
            }

            var template = $@"
            {{
                {string.Join(",\n", aceData)}
            }}
            ";

            return Util.FormatJson(template);
        }

        private IEnumerable<string> GetCategroy(Aces ace)
        {
            HashSet<string> results = new HashSet<string>();

            foreach (var action in ace.Actions)
            {
                results.Add(action.CategoryID);
            }

            foreach (var condition in ace.Conditions)
            {
                results.Add(condition.CategoryID);
            }

            foreach (var expression in ace.Expressions)
            {
                results.Add(expression.CategoryID);
            }

            return results;
        }

        private string GenerateCategoryJson(string category, Aces ace)
        {
            var template = $@"
                ""{category}"" : {{
                    ""conditions"": [ 
                        {GenerateConditionsString(category, ace)} 
                    ],
                    ""actions"": [ 
                        {GenerateActionString(category, ace)} 
                    ],
                    ""expressions"": [ 
                        {GenerateExpressionString(category, ace)} 
                    ]
                }}
            ";

            return template;
        }

        private string GenerateConditionsString(string category, Aces ace)
        {
            List<string> conditions = new List<string>();

            foreach (var condition in ace.Conditions.Where(x => x.CategoryID == category))
            {
                var template = $@"
                    {{
                        ""id"" : ""{condition.ID}"",
                        ""scriptName"" : ""{condition.ScriptName}"",
                        ""isTrigger"" : ""{Util.BoolStr(condition.IsTrigger)}"",
                        ""highlight"" : ""{Util.BoolStr(condition.Highlight)}"",
                        ""params"" : [
                            {GenerateAceParamString(condition.Parameters)}
                        ],
                        ""c2id"" : {condition.C2ID}
                    }}
                    ";

                conditions.Add(template);
            }

            return string.Join(",\n", conditions);
        }

        private string GenerateActionString(string category, Aces ace)
        {
            List<string> actions = new List<string>();

            foreach (var action in ace.Actions.Where(x => x.CategoryID == category))
            {
                var template = $@"
                    {{
                        ""id"" : ""{action.ID}"",
                        ""scriptName"" : ""{action.ScriptName}"",
                        ""highlight"" : ""{Util.BoolStr(action.Highlight)}"",
                        ""params"" : [
                            {GenerateAceParamString(action.Parameters)}
                        ],
                        ""c2id"" : {action.C2ID}
                    }}
                    ";

                actions.Add(template);
            }

            return string.Join(",\n", actions);
        }

        private string GenerateExpressionString(string category, Aces ace)
        {
            List<string> expressions = new List<string>();

            foreach (var exp in ace.Expressions.Where(x => x.CategoryID == category))
            {
                var template = $@"
                    {{
                        ""id"" : ""{exp.ID}"",
                        ""expressionName"" : ""{exp.ExpressionName}"",
                        ""highlight"" : ""{Util.BoolStr(exp.Highlight)}"",
                        ""returnType"" : ""{exp.ReturnType}"",
                        ""params"" : [
                            {GenerateAceParamString(exp.Parameters)}
                        ],
                        ""c2id"" : {exp.C2ID}
                    }}
                    ";

                expressions.Add(template);
            }

            return string.Join(",\n", expressions);
        }

        private string GenerateAceParamString (IEnumerable<AceParameter> paramList) 
        {
            List<string> results = new List<string>();

            foreach (var param in paramList)
            {
                var template = $@"{{ ""id"" : ""{param.ID}"", ""type"" : ""{param.Type}"", ""initialValue"" : ""{param.InitalValue}""}}";

                if (param.Type == AceParameterType.Combo)
                {
                    var itemStrings = string.Join(",", param.ItemsNames.Keys.Select(x => $"\"{x}\""));
                    template = $@"{{ ""id"" : ""{param.ID}"", ""type"" : ""{param.Type}"", ""initialValue"" : ""{param.InitalValue}"", ""items"" : [ {itemStrings}] }}";
                }

                results.Add(template);
            }

            return string.Join(",\n\t\t\t\t\t\t\t", results);
        }
    }
}
