﻿using System;
using System.Collections.Generic;
using C3PluginGen.Framework;
using C3PluginGen.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace C3PluginGen.Test
{
    [TestClass]
    public class FileGeneratorTest
    {
        [TestMethod]
        public void AddonJsonTest()
        {
            var addon = GetAddon();
            AddonJsonGenerator gen = new AddonJsonGenerator();
            var results = gen.Generate(addon);
            Console.Write(results);
        }

        [TestMethod]
        public void PluginJsTest()
        {
            var plugin = GetPlugin();
            PluginJsGenerator gen = new PluginJsGenerator();
            var results = gen.Generate(plugin);
            Console.Write(results);
        }

        [TestMethod]
        public void BehaviorJsTest()
        {
            var behavior = GetBehavior();
            BehaviorJsGenerator gen = new BehaviorJsGenerator();
            var results = gen.Generate(behavior);
            Console.Write(results);
        }

        [TestMethod]
        public void InstanceJsTest()
        {
            var plugin = GetPlugin();
            InstanceJsPluginGenerator gen = new InstanceJsPluginGenerator();
            var resuls = gen.Generate(plugin);
            Console.WriteLine(resuls);
        }

        [TestMethod]
        public void TypeJsTest()
        {
            var plugin = GetPlugin();
            TypeJsPluginGenerator gen = new TypeJsPluginGenerator();
            var resuls = gen.Generate(plugin);
            Console.WriteLine(resuls);
        }

        [TestMethod]
        public void AcesJsonTest()
        {
            var aces = GetAces();
            AcesJsonGenerator gen = new AcesJsonGenerator();
            var results = gen.Generate(aces);
            Console.Write(results);
        }

        [TestMethod]
        public void LanguageJsonTest()
        {
            var lang = GetLang();
            LanguageJsonGenerator gen = new LanguageJsonGenerator();
            var results = gen.Generate(lang);
            Console.Write(results);
        }

        private Addon GetAddon()
        {
            Addon addon = new Addon
            {
                IsC3Addon = true,
                Type = AddonType.Plugin,
                PluginID = "test_id",
                PluginName = "Test Plugin",
                Version = "0.0.0.0",
                Author = "tester",
                Website = "www.test.com",
                Description = "This is a test plugin",
                Documentation = "www.testdoc.com",
                DevelopmentMode = false,
            };

            addon.AddEdiotrScript("test1.js");
            addon.AddEdiotrScript("test2.js");
            addon.AddFileDependency("dep.js");

            return addon;
        }

        private Plugin GetPlugin()
        {
            Plugin plugin = new Plugin
            {
                PluginID = "pluginid",
                PluginClass = "PluginClass",
                Version = "0.0.0.0",
                Category = "TestCat",
                IconPath = "icon/",
                IconFile = "ico.ico",
                Description = "Plugin Description",
                Author = "me",
                HelpUrl = "www.help.com",
                ShowIsSingleGlobalPlugin = true,
                IsSingleGlobalPlugin = true,
                ShowIsDeprecated = true,
                IsDeprecated = false,
                ShowHasImage = true,
                Properties = new List<PluginProperty>
                {
                    PluginProperty.Create("prop1", "property1", "prop 1 desc", PluginPropertyType.Check)
                        .WithOption(PluginPropertyOptionType.InitialValue, "test1"),
                    PluginProperty.Create("prop2", "property2", "prop 2 desc", PluginPropertyType.Combo)
                        .WithOption(PluginPropertyOptionType.InitialValue, "test2")
                        .WithItem("test", "test2")
                        .WithItem("test2", "test2"),
                    PluginProperty.Create("prop3", "property3", "This is Property 3", PluginPropertyType.Link)
                        .WithOption(PluginPropertyOptionType.LinkCallback, "tes3t")
                        .WithLinkText("test link")
                }
            };


            return plugin;
        }

        private Behavior GetBehavior()
        {
            Behavior plugin = new Behavior
            {
                BehaviorID = "behaviorid",
                BehaviorClass = "BehaviorClass",
                Version = "0.0.0.0",
                Category = "TestCat",
                IconPath = "icon/",
                IconFile = "ico.ico",
                Description = "behavior Description",
                Author = "me",
                HelpUrl = "www.help.com",
                ShowIsOnlyOneAllowed = true,
                IsOnlyOneAllowed = true,
                ShowIsDeprecated = true,
                IsDeprecated = false,
                ShowCanBeBundled = true,
                Properties = new List<PluginProperty>
                {
                    PluginProperty.Create("prop1", "property1", "prop 1 desc", PluginPropertyType.Check)
                        .WithOption(PluginPropertyOptionType.InitialValue, "test1"),
                    PluginProperty.Create("prop2", "property2", "prop 2 desc", PluginPropertyType.Combo)
                        .WithOption(PluginPropertyOptionType.InitialValue, "test2")
                        .WithItem("test", "test2")
                        .WithItem("test2", "test2"),
                    PluginProperty.Create("prop3", "property3", "This is Property 3", PluginPropertyType.Link)
                        .WithOption(PluginPropertyOptionType.LinkCallback, "tes3t")
                        .WithLinkText("test link")
                }
            };


            return plugin;
        }

        private Aces GetAces()
        {
            Actions action = new Actions
            {
                CategoryID = "test",
                CategoryName = "Test 1",
                C2ID = "1",
                Description = "this action",
                DisplayText = "Actionnnn Test",
                Highlight = true,
                ID = "test-action",
                IsDeprecated = false,
                ListName = "test action",
                Name = "testaction",
                ScriptName = "function_test"
            };

            action.Parameters = new List<AceParameter>
            {
                AceParameter.Create("test", "Test", "Test1", "0", AceParameterType.Number),
                AceParameter.Create("list","List","List1","0", AceParameterType.Combo).WithItem("1","1").WithItem("2","1").WithItem("3","1").WithItem("4","1")
            };

            Condition condition = new Condition
            {
                CategoryID = "test",
                CategoryName = "Test 1",
                C2ID = "1",
                Description = "this action",
                DisplayText = "Actionnnn Test",
                Highlight = true,
                ID = "test-action",
                IsDeprecated = false,
                ListName = "test action",
                Name = "testaction",
                ScriptName = "function_test",
                IsTrigger = true,
                IsFakeTrigger = false,
                IsStatic = true,
                IsLooping = true,
                IsCompatibleWithTriggers = false,
                IsInvertible = false
            };

            condition.Parameters = new List<AceParameter>
            {
                AceParameter.Create("test", "Test", "Test1", "0", AceParameterType.Number),
                AceParameter.Create("list","List","List1","0", AceParameterType.Combo).WithItem("1","1").WithItem("2","1").WithItem("3","1").WithItem("4","1")
            };

            Expression expression = new Expression
            {
                CategoryID = "test",
                CategoryName = "Test 1",
                C2ID = "1",
                Description = "this action",
                Highlight = true,
                ID = "test-action",
                IsDeprecated = false,
                Name = "testaction",
                ExpressionName = "function_test",
                ReturnType = ExpressionReturnType.Any
            };

            expression.Parameters = new List<AceParameter>
            {
                AceParameter.Create("test", "Test", "Test1", "0", AceParameterType.Number),
                AceParameter.Create("list","List","List1","0", AceParameterType.Combo).WithItem("1","1").WithItem("2","1").WithItem("3","1").WithItem("4","1")
            };

            Aces aces = new Aces
            {
                Actions = new List<Actions> { action, action },
                Conditions = new List<Condition> { condition, condition },
                Expressions = new List<Expression> { expression, expression }
            };

            return aces;
        }

        private Language GetLang()
        {
            Language lang = new Language
            {
                Aces = GetAces(),
                Addon = GetAddon(),
                Plugin = GetPlugin(),
                LanguageTag = "en-US"
            };

            return lang;
        }
    }
}
