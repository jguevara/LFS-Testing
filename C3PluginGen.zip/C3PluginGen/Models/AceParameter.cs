﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class AceParameter : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        //A string with a unique identifier for this parameter. This is used to refer to the parameter in the language file.
        public string ID { get; set; }
        //In some circumstances, it is necessary to specify which Construct 2 parameter ID a parameter corresponds to. However normally it can be inferred by the parameter index.
        public string C2ID { get; set; }
        //The parameter type. Expressions can only use "number", "string" or "any". However conditions and actions have more types
        public string Type { get; set; }
        //A string which is used as the initial expression for expression-based parameters. Note this is still a string for "number" 
        //type parameters. It can contain any valid expression for the parameter, such as "1 + 1". For "combo" parameters, this is the initial item ID
        public string InitalValue { get; set; }

        //Actions, conditions and expressions can omit the "params" key if they have no parameters. However if they have any parameters this key must be 
        //present, and each parameter must have its own key inside with the ID of the parameter. Similar to the plugin properties, each key must have a "name", 
        //"desc" and for combo parameters, "items" (which work the same as "combo" property types: each item ID maps to its display text).
        public string Name { get; set; }
        public string Description { get; set; }
        //Only valid with the "combo" type. Set to an array of item IDs available in the dropdown list. The actual displayed text for the items is defined in the language file.
        public Dictionary<string, string> ItemsNames { get; set; }

        public AceParameter()
        {
            ItemsNames = new Dictionary<string, string>();
        }


        public AceParameter WithItem(string key, string value)
        {
            ItemsNames.Add(key, value);
            return this;
        }

        public static AceParameter Create(string id, string name, string desc, string initValue, string type)
        {
            return new AceParameter()
            {
                Name = name,
                Description = desc,
                ID = id,
                InitalValue = initValue,   
                Type = type
            };
        }

        public override bool Equals(object obj)
        {
            try
            {
                return this.ID == ((AceParameter)obj)?.ID;
            }
            catch
            {
                return false;
            }

        }

        public override int GetHashCode()
        { 
            return this.ID.GetHashCode();
        }
    }

    public static class AceParameterType
    {
        public const string Number = "number";
        public const string String = "string";
        public const string Any = "any";
        public const string Combo = "combo";
        public const string Comparison = "cmp";
        public const string Object = "object";
        public const string ObjectName = "objectname";
        public const string Layer = "layer";
        public const string KeyboardKey = "keyb";
        public const string InstanceVariable = "instancevar";
        public const string InstanceBoolean = "instancevarbool";
        public const string EventVariable = "eventvar";
        public const string EventBoolean = "eventvarbool";
        public const string Animation = "animation";
        public const string Variadic = "variadic";
        public const string ObjectInstanceVariable = "objectinstancevar";
    }
}
