﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for PluginView.xaml
    /// </summary>
    public partial class PluginView : UserControl
    {
        public Plugin Plugin { get; set; }

        public PluginView()
        {
            Plugin = new Plugin();

            InitializeComponent();

            EventBus.Hub.Subscribe<AddonNameChangedEvent>(AddonNameChange);
            EventBus.Hub.Subscribe<PluginExportEvent>(BuildPlugin);

            FieldInfo[] properties = typeof(PluginType).GetFields();
            PluginType.ItemsSource = properties.Select(x => x.Name);

            //select plugin
            PluginType.SelectedIndex = 0;
        }

        private void BuildPlugin(PluginExportEvent obj)
        {
            Plugin.PluginClass = PluginClass.Text;
            Plugin.PluginType = PluginType.Text;

            Plugin.IsSingleGlobalPlugin = IsSingleGlobalPlugin.IsChecked != null && (IsSingleGlobalPlugin.IsChecked.Value);
            Plugin.ShowCanBeBundled = DisplayCanBeBundled.IsChecked != null && (DisplayCanBeBundled.IsChecked.Value);
            Plugin.IsResizable = IsResizable.IsChecked != null && (IsResizable.IsChecked.Value);
            Plugin.IsRotatable = IsRotatable.IsChecked != null && (IsRotatable.IsChecked.Value);
            Plugin.HasImage = HasImage.IsChecked != null && (HasImage.IsChecked.Value);
            Plugin.IsTiled = IsTiled.IsChecked != null && (IsTiled.IsChecked.Value);
            Plugin.SupportsEffects = SupportEffects.IsChecked != null && (SupportEffects.IsChecked.Value);
            Plugin.MustPreDraw = MustPreDraw.IsChecked != null && (MustPreDraw.IsChecked.Value);
            Plugin.IsDeprecated = IsDeprecated.IsChecked != null && (IsDeprecated.IsChecked.Value);

            Plugin.ShowIsSingleGlobalPlugin = DisplayIsSingleGlobalPlugin.IsChecked != null && (DisplayIsSingleGlobalPlugin.IsChecked.Value);
            Plugin.ShowCanBeBundled = DisplayCanBeBundled.IsChecked != null && (DisplayCanBeBundled.IsChecked.Value);
            Plugin.ShowIsResizable = DisplayIsResizable.IsChecked != null && (DisplayIsResizable.IsChecked.Value);
            Plugin.ShowIsRotatable = DisplayIsRotatable.IsChecked != null && (DisplayIsRotatable.IsChecked.Value);
            Plugin.ShowHasImage = DisplayHasImage.IsChecked != null && (DisplayHasImage.IsChecked.Value);
            Plugin.ShowIsTiled = DisplayIsTiled.IsChecked != null && (DisplayIsTiled.IsChecked.Value);
            Plugin.ShowSupportsEffects = DisplaySupportEffects.IsChecked != null && (DisplaySupportEffects.IsChecked.Value);
            Plugin.ShowMustPreDraw = DisplayMustPreDraw.IsChecked != null && (DisplayMustPreDraw.IsChecked.Value);
            Plugin.ShowIsDeprecated = DisplayIsDeprecated.IsChecked != null && (DisplayIsDeprecated.IsChecked.Value);
        }

        private void AddonNameChange(AddonNameChangedEvent obj)
        {
            PluginClass.Text = obj.Name.Replace(" ", string.Empty);
        }
    }
}
