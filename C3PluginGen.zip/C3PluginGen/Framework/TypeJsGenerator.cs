﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class TypeJsFactory
    {
        public static IGenerator<Plugin> CreateGenerator(Plugin plugin)
        {
            return new TypeJsPluginGenerator();
        }

        public static IGenerator<Behavior> CreateGenerator(Behavior behavior)
        {
            return new TypeJsBehaviorGenerator();
        }
    }

    public class TypeJsPluginGenerator : IGenerator<Plugin>
    {
        public string Generate(Plugin type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const PLUGIN_CLASS = SDK.Plugins.{type.PluginClass};
                
                PLUGIN_CLASS.Type = class {type.PluginClass}Type extends SDK.ITypeBase
                {{
                    constructor(sdkPlugin, iObjectType)
		            {{
                        super(sdkPlugin, iObjectType);
                    }}
                }};
            }}
            ";

            return template;
        }
    }

    public class TypeJsBehaviorGenerator : IGenerator<Behavior>
    {
        public string Generate(Behavior type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const BEHAVIOR_CLASS = SDK.Plugins.{type.BehaviorClass};
                
                BEHAVIOR_CLASS.Type = class {type.BehaviorClass}Type extends SDK.IBehaviorTypeBase
                {{
                    constructor(sdkPlugin, iBehaviorType)
		            {{
                        super(sdkPlugin, iBehaviorType);
                    }}
                }};
            }}
            ";

            return template;
        }
    }
}
