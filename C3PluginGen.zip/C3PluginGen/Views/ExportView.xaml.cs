﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;
using Condition = C3PluginGen.Models.Condition;
using Expression = C3PluginGen.Models.Expression;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for ExportView.xaml
    /// </summary>
    public partial class ExportView : UserControl
    {
        public MainWindow Main { get; set; }
        private string rootFolderPath;
        private string addonFolderPath;

        public ExportView()
        {
            InitializeComponent();
        }

        private void ExportPlugin_Click(object sender, RoutedEventArgs e)
        {
            rootFolderPath = Path.Text;
            if (string.IsNullOrEmpty(rootFolderPath))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "File Path Not Valid"));
                return;
            }

            //request updated models
            EventBus.Hub.Publish(new AddonExportEvent(this));
            EventBus.Hub.Publish(new PluginExportEvent(this));
            EventBus.Hub.Publish(new BehaviorExportEvent(this));

            //pull models from ui state
            Addon addon = Main.Addon.Addon;
            Plugin plugin = Main.Plugin.Plugin;
            Behavior behavior = Main.Behavior.Behavior;
            IEnumerable<PluginProperty> properties = Main.Properties.Properties.ToList();
            IEnumerable<Actions> actions = Main.Actions.Actions.ToList();
            IEnumerable<Condition> conditions = Main.Conditions.Conditions.ToList();
            IEnumerable<Expression> expressions = Main.Expressions.Expressions.ToList();
            plugin.Properties = properties.ToList();
            behavior.Properties = properties.ToList();
            Aces aces = new Aces
            {
                Actions = actions.ToList(),
                Conditions = conditions.ToList(),
                Expressions = expressions.ToList()
            };
            Language lang = new Language
            {
                Aces = aces,
                LanguageTag = "en-US",
                Addon = addon,
                Plugin = plugin,
                Behavior = behavior
            };

            CreateAddonDirectory(addon);

            CreateAddon(addon);

            switch (addon.Type)
            {
                case "Plugin":
                    CreatePlugin(plugin);
                    break;
                case "Behavior":
                    CreateBehavior(behavior);
                    break;
            }

            CreateAces(aces);
            CreateLang(lang);
        }

        private void CreateAddonDirectory(Addon addon)
        {
            if(!Directory.Exists(rootFolderPath))
            {
                Directory.CreateDirectory(rootFolderPath);
            }

            var addonName = addon.PluginID;
            addonFolderPath = System.IO.Path.Combine(rootFolderPath, addonName);

            if (!Directory.Exists(addonFolderPath))
            {
                Directory.CreateDirectory(addonFolderPath);
            }
        }

        private void CreateAddon(Addon addon)
        {
            var gen = new AddonJsonGenerator();
            var str = gen.Generate(addon);
            var path = $"{addonFolderPath}\\Addon.json";

            File.WriteAllText(path, str);
        }

        private void CreateLang(Language lang)
        {
            var gen = new LanguageJsonGenerator();
            var str = gen.Generate(lang);

            Directory.CreateDirectory(System.IO.Path.Combine(addonFolderPath, "lang"));

            var path = $"{addonFolderPath}\\lang\\{lang.LanguageTag}.json";
            File.WriteAllText(path, str);
        }

        private void CreateAces(Aces aces)
        {
            var gen = new AcesJsonGenerator();
            var str = gen.Generate(aces);
            var path = $"{addonFolderPath}\\aces.json";

            File.WriteAllText(path, str);
        }

        private void CreateBehavior(Behavior behavior)
        {
            var gen = AddonTypeJsFactory.CreateGenerator(behavior);
            var str = gen.Generate(behavior);
            var path = $"{addonFolderPath}\\behavior.js";
            File.WriteAllText(path, str);

            //instance
            gen = InstanceJsFactory.CreateGenerator(behavior);
            str = gen.Generate(behavior);
            path = $"{addonFolderPath}\\instance.js";
            File.WriteAllText(path, str);

            //type
            gen = TypeJsFactory.CreateGenerator(behavior);
            str = gen.Generate(behavior);
            path = $"{addonFolderPath}\\type.js";
            File.WriteAllText(path, str);
        }

        private void CreatePlugin(Plugin plugin)
        {
            var gen = AddonTypeJsFactory.CreateGenerator(plugin);
            var str = gen.Generate(plugin);
            var path = $"{addonFolderPath}\\plugin.js";
            File.WriteAllText(path, str);

            //instance
            gen = InstanceJsFactory.CreateGenerator(plugin);
            str = gen.Generate(plugin);
            path = $"{addonFolderPath}\\instance.js";
            File.WriteAllText(path, str);

            //type
            gen = TypeJsFactory.CreateGenerator(plugin);
            str = gen.Generate(plugin);
            path = $"{addonFolderPath}\\type.js";
            File.WriteAllText(path, str);
        }
    }
}
