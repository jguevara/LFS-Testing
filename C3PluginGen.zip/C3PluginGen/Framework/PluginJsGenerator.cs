﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class AddonTypeJsFactory
    {
        public static IGenerator<Plugin> CreateGenerator(Plugin plugin)
        {
            return new PluginJsGenerator();
        }

        public static IGenerator<Behavior> CreateGenerator(Behavior behavior)
        {
            return new BehaviorJsGenerator();
        }
    }

    public class PluginJsGenerator : IGenerator<Plugin>
    {
        public string Generate(Plugin type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const PLUGIN_ID = ""{type.PluginID}"";
                const PLUGIN_VERSION = ""{type.Version}"";
                const PLUGIN_CATEGORY = ""{type.Category}"";

                let app = null;
                
                const PLUGIN_CLASS = SDK.Plugins.{type.PluginClass} = class {type.PluginClass} extends SDK.IPluginBase
                {{
                    constructor()
                    {{
                        super(PLUGIN_ID);
                        SDK.Lang.PushContext(""plugins."" + PLUGIN_ID.toLowerCase());
                        this._info.SetIcon(""icon.png"", ""image/png"");
                        this._info.SetName(lang("".name"")); 
        			    this._info.SetDescription(lang("".description""));
                        this._info.SetVersion(PLUGIN_VERSION);
                        this._info.SetCategory(PLUGIN_CATEGORY);
                        this._info.SetAuthor(""{type.Author}"");
			            this._info.SetHelpUrl(lang("".help - url""));
                        {ShowPluginSetting(type)}
                        SDK.Lang.PushContext("".properties"");  
                        this._info.SetProperties([
                            {GeneratrPropertyString(type)}
                        ]);
                        this._info.AddFileDependency([
                            {GenerateFileDependencyString(type)}
                        ]);
                        SDK.Lang.PopContext();		// .properties
			            SDK.Lang.PopContext();
                    }}
                }};
                
                PLUGIN_CLASS.Register(PLUGIN_ID, PLUGIN_CLASS);
            }}
            ";

            return template;
        }

        private string ShowPluginSetting(Plugin type)
        {
            var settings = new List<string>();

            if (type.ShowIsSingleGlobalPlugin) settings.Add($"this._info.SetIsSingleGlobal({ Util.BoolStr(type.IsSingleGlobalPlugin)});");
            if (type.ShowIsDeprecated) settings.Add($"this._info.SetIsDeprecated({ Util.BoolStr(type.IsDeprecated)});");
            if (type.ShowCanBeBundled) settings.Add($"this._info.SetCanBeBundled({ Util.BoolStr(type.CanBeBundled)});");
            if (type.ShowHasImage) settings.Add($"this._info.SetHasImage({ Util.BoolStr(type.HasImage)});");
            if (type.ShowIsResizable) settings.Add($"this._info.SetIsResizable({ Util.BoolStr(type.IsResizable)});");
            if (type.ShowIsRotatable) settings.Add($"this._info.SetIsRotatable({ Util.BoolStr(type.IsRotatable)});");
            if (type.ShowIsTiled) settings.Add($"this._info.SetIsTiled({ Util.BoolStr(type.IsTiled)});");
            if (type.ShowMustPreDraw) settings.Add($"this._info.SetMustPreDraw({ Util.BoolStr(type.MustPreDraw)});");
            if (type.ShowSupportsEffects) settings.Add($"this._info.SetSupportsEffects({ Util.BoolStr(type.SupportsEffects)});");

            return string.Join("\n\t\t\t\t\t\t", settings);
        }

        private string GeneratrPropertyString(Plugin type)
        {
            List<string> props = new List<string>();
            
            foreach (PluginProperty property in type.Properties)
            {
                List<string> opts = new List<string>();
                foreach (var options in property.Options)
                {
                    opts.Add($@"{options.Type}:""{options.Value}""");
                }

                if (property.ItemsNames.Any())
                {
                    var itemStrings = string.Join(",", property.ItemsNames.Keys.Select(x => $"\"{x}\""));
                    opts.Add($"items:[{itemStrings}]");
                }

                props.Add($@"new SDK.PluginProperty(""{property.Type}"", ""{property.PropertyId}"", {{ {string.Join(", ", opts)} }})");
            }

            return string.Join(",\n\t\t\t\t\t\t\t", props);
        }

        private string GenerateFileDependencyString(Plugin type)
        {
            List<string> deps = new List<string>();

            foreach (FileDependency fileDependency in type.FileDependency)
            {
                deps.Add($@"{{filename:""{fileDependency.File}"", type:""{fileDependency.Type}""}}");
            }

            return string.Join(",\n\t\t\t\t\t\t\t", deps);
        }
    }

    public class BehaviorJsGenerator : IGenerator<Behavior>
    {
        public string Generate(Behavior type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const BEHAVIOR_ID = ""{type.BehaviorID}"";
                const BEHAVIOR_VERSION = ""{type.Version}"";
                const BEHAVIOR_CATEGORY = ""{type.Category}"";

                const BEHAVIOR_CLASS = SDK.Behaviors.{type.BehaviorClass} = class {type.BehaviorClass} extends SDK.IBehaviorBase
                {{
                    constructor()
                    {{
                        super(BEHAVIOR_ID);
                        SDK.Lang.PushContext(""behaviors."" + BEHAVIOR_ID.toLowerCase());
                        this._info.SetIcon(""icon.png"", ""image/png"");
                        this._info.SetName(lang("".name"")); 
        			    this._info.SetDescription(lang("".description""));
                        this._info.SetVersion(BEHAVIOR_VERSION);
                        this._info.SetCategory(BEHAVIOR_CATEGORY);
                        this._info.SetAuthor(""{type.Author}"");
			            this._info.SetHelpUrl(lang("".help - url""));
                        {ShowPluginSetting(type)}
                        SDK.Lang.PushContext("".properties"");  
                        this._info.SetProperties([
                            {GeneratrPropertyString(type)}
                        ]);
                        this._info.AddFileDependency([
                            {GenerateFileDependencyString(type)}
                        ]);
                        SDK.Lang.PopContext();		// .properties
			            SDK.Lang.PopContext();
                    }}
                }};
                
                BEHAVIOR_CLASS.Register(BEHAVIOR_ID, BEHAVIOR_CLASS);
            }}
            ";

            return template;
        }

        private string ShowPluginSetting(Behavior type)
        {
            var settings = new List<string>();

            if (type.ShowIsOnlyOneAllowed) settings.Add($"this._info.SetIsSingleGlobal({ Util.BoolStr(type.IsOnlyOneAllowed)});");
            if (type.ShowIsDeprecated) settings.Add($"this._info.SetIsDeprecated({ Util.BoolStr(type.IsDeprecated)});");
            if (type.ShowCanBeBundled) settings.Add($"this._info.SetCanBeBundled({ Util.BoolStr(type.CanBeBundled)});");

            return string.Join("\n\t\t\t\t\t\t", settings);
        }

        private string GeneratrPropertyString(Behavior type)
        {
            List<string> props = new List<string>();

            foreach (PluginProperty property in type.Properties)
            {
                List<string> opts = new List<string>();
                foreach (var options in property.Options)
                {
                    opts.Add($@"{options.Type}:""{options.Value}""");
                }

                if (property.ItemsNames.Any())
                {
                    var itemStrings = string.Join(",", property.ItemsNames.Keys.Select(x => $"\"{x}\""));
                    opts.Add($"items:[{itemStrings}]");
                }

                props.Add($@"new SDK.PluginProperty(""{property.Type}"", ""{property.PropertyId}"", {{ {string.Join(", ", opts)} }})");
            }

            return string.Join(",\n\t\t\t\t\t\t\t", props);
        }

        private string GenerateFileDependencyString(Behavior type)
        {
            List<string> deps = new List<string>();

            foreach (FileDependency fileDependency in type.FileDependency)
            {
                deps.Add($@"{{filename:""{fileDependency.File}"", type:""{fileDependency.Type}""}}");
            }

            return string.Join(",\n\t\t\t\t\t\t\t", deps);
        }
    }
}
