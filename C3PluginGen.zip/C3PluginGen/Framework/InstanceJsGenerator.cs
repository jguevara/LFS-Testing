﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public class InstanceJsFactory
    {
        public static IGenerator<Plugin> CreateGenerator(Plugin plugin)
        {
            return new InstanceJsPluginGenerator();
        }

        public static IGenerator<Behavior> CreateGenerator(Behavior behavior)
        {
            return new InstanceJsBehaviorGenerator();
        }
    }

    public class InstanceJsPluginGenerator : IGenerator<Plugin>
    {
        public string Generate(Plugin type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const PLUGIN_CLASS = SDK.Plugins.{type.PluginClass};
                
                PLUGIN_CLASS.Instance = class {type.PluginClass}Instance extends SDK.IInstanceBase
                {{
                    constructor(sdkPlugin, inst)
		            {{
                        super(sdkPlugin, inst);
                    }}
    
                    Release()
		            {{
		            }}

		            OnCreate()
		            {{
		            }}

		            OnPropertyChanged(id, value)
		            {{
		            }}

		            LoadC2Property(name, valueString)
		            {{
			            return false;       // not handled
		            }}
                }};
            }}
            ";

            return template;
        }
    }

    public class InstanceJsBehaviorGenerator : IGenerator<Behavior>
    {
        public string Generate(Behavior type)
        {
            var template = $@"
            ""use strict"";
        
            {{
                const BEHAVIOR_CLASS = SDK.Plugins.{type.BehaviorClass};
                
                BEHAVIOR_CLASS.Instance = class {type.BehaviorClass}Instance extends SDK.IBehaviorInstanceBase
                {{
                    constructor(sdkBehType, behInst)
		            {{
                        super(sdkBehType, behInst);
                    }}
    
                    Release()
		            {{
		            }}

		            OnCreate()
		            {{
		            }}

		            OnPropertyChanged(id, value)
		            {{
		            }}

		            LoadC2Property(name, valueString)
		            {{
			            return false;       // not handled
		            }}
                }};
            }}
            ";

            return template;
        }
    }
}
