﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace C3PluginGen.Models
{
    public class Behavior : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        //This is a unique ID that identifies your plugin from all other addons. This must not be used by any other 
        //addon ever published for Construct 3. It must never change after you first publish your addon. (The name is 
        //the only visible identifier of the addon in the Construct 3 editor, so that can be changed any time, but the 
        //ID must always be the same.) To ensure it is unique, it is recommended to use a vendor-addon format,
        //e.g. mycompany-superaddon.
        public string BehaviorID { get; set; }
        //The class name suffixed with Type or Instance. (For example the Audio plugin uses AudioPlugin, AudioType and 
        //AudioInstance as the three names.)
        public string BehaviorClass { get; set; }
        //A string specifying the addon version in four parts (major, minor, patch, revision). Be sure to update 
        //this when releasing updates to your addon, which must also be updated in addon.json.
        public string Version { get; set; }
        //The category for the plugin when displaying it in the Create New Object Type dialog. 
        //This must be one of "data-and-storage", "form-controls", "general", "input", "media", "monetisation", 
        //"platform-specific", "web", "other".
        public string Category { get; set; }
        public string IconPath { get; set; }
        public string IconFile { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }
        public string HelpUrl { get; set; }
        public List<PluginProperty> Properties { get; set; }
        public List<FileDependency> FileDependency { get; set; }

        //lazy settings
        public bool IsOnlyOneAllowed { get; set; }
        public bool IsDeprecated { get; set; }
        public bool CanBeBundled { get; set; }

        //private lazy display settings
        public bool ShowIsOnlyOneAllowed = false;
        public bool ShowIsDeprecated = false;
        public bool ShowCanBeBundled = false;

        public Behavior()
        {
            Properties = new List<PluginProperty>();
            FileDependency = new List<FileDependency>();
        }

        public void AddProperty(PluginProperty property)
        {
            Properties.Add(property);
        }
    }
}
