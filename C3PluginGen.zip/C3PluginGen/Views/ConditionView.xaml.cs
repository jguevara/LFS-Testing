﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;
using Condition = C3PluginGen.Models.Condition;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for ConditionView.xaml
    /// </summary>
    public partial class ConditionView : UserControl
    {
        public ObservableCollection<Condition> Conditions { get; set; }
        public ObservableCollection<AceParameter> Parameters { get; set; }
        public Dictionary<string, string> Items { get; set; }


        public ConditionView()
        {
            Conditions = new ObservableCollection<Condition>();
            Items = new Dictionary<string, string>();
            Parameters = new ObservableCollection<AceParameter>();

            InitializeComponent();
            DataContext = this;

            FieldInfo[] types = typeof(AceParameterType).GetFields();
            ParameterType.ItemsSource = types.Select(x => x.Name);
            ParameterType.SelectedIndex = 0;
        }

        private void DeleteConditionButton_Click(object sender, RoutedEventArgs e)
        {
            if (ConditionListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Condition Selected"));
                return;
            }

            var condition = (Condition)ConditionListBox.SelectedItem;
            Conditions.Remove(condition);

            ClearItemList();

            ClearParameterList();

            ClearInputFields();
        }


        private void EditConditionButton_Click(object sender, RoutedEventArgs e)
        {
            if (ConditionListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Condition Selected"));
                return;
            }

            var condition = (Condition)ConditionListBox.SelectedItem;

            ConditionName.Text = condition.Name;
            ConditionID.Text = condition.ID;
            CategoryID.Text = condition.CategoryID;
            CategoryName.Text = condition.CategoryName;
            ScriptName.Text = condition.ScriptName;
            DisplayText.Text = condition.DisplayText;
            Description.Text = condition.Description;
            HighlightCheck.IsChecked = condition.Highlight;
            IsDeprecatedCheck.IsChecked = condition.IsDeprecated;
            IsTriggertCheck.IsChecked = condition.IsTrigger;
            IsFakeTriggerCheck.IsChecked = condition.IsFakeTrigger;
            IsStaticCheck.IsChecked = condition.IsStatic;
            IsLoopingCheck.IsChecked = condition.IsLooping;
            IsInvertible.IsChecked = condition.IsInvertible;
            IsCompatibleWithTriggers.IsChecked = condition.IsCompatibleWithTriggers;

            Parameters = new ObservableCollection<AceParameter>(condition.Parameters);
            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();
        }

        private void AddConditionButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ConditionID.Text))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Ivalid Condition ID"));
                return;
            }

            var highlight = HighlightCheck.IsChecked != null && (HighlightCheck.IsChecked.Value);
            var deprecated = IsDeprecatedCheck.IsChecked != null && (IsDeprecatedCheck.IsChecked.Value);
            var isTrigger = IsTriggertCheck.IsChecked != null && (IsTriggertCheck.IsChecked.Value);
            var isFakeTrigger = IsFakeTriggerCheck.IsChecked != null && (IsFakeTriggerCheck.IsChecked.Value);
            var isStatic = IsStaticCheck.IsChecked != null && (IsStaticCheck.IsChecked.Value);
            var isLoop = IsLoopingCheck.IsChecked != null && (IsLoopingCheck.IsChecked.Value);
            var isInvertible = IsInvertible.IsChecked != null && (IsInvertible.IsChecked.Value);
            var isCompatibleWithTriggers = IsCompatibleWithTriggers.IsChecked != null && (IsInvertible.IsChecked.Value);

            var condition = new Condition
            {
                Name = ConditionName.Text,
                ID = ConditionID.Text,
                CategoryID = CategoryID.Text,
                CategoryName = CategoryName.Text,
                ScriptName = ScriptName.Text,
                DisplayText = DisplayText.Text,
                Description = Description.Text,
                Highlight = highlight,
                IsDeprecated = deprecated,
                IsTrigger = isTrigger,
                IsFakeTrigger = isFakeTrigger,
                IsStatic = isStatic,
                IsLooping = isLoop,
                IsInvertible = isInvertible,
                IsCompatibleWithTriggers = isCompatibleWithTriggers,
                Parameters = Parameters.ToList()
            };

            Conditions.Remove(condition);
            Conditions.Add(condition);

            ClearItemList();
            ClearParameterList();
            ClearInputFields();
        }

        private void AddParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ParameterID.Text))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Invalid Parameter ID"));
                return;
            }

            var param = new AceParameter
            {
                ID = ParameterID.Text,
                Name = ParameterName.Text,
                Description = ParameterDesc.Text,
                InitalValue = ParameterInitVal.Text,
                Type = ParameterType.Text,
                ItemsNames = Items
            };

            Parameters.Remove(param);
            Parameters.Add(param);

            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();

            ClearItemList();
            ClearParamFields();
        }

        private void RemoveParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (ParameterListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Parameter Selected"));
                return;
            }

            var param = (AceParameter)ParameterListBox.SelectedItem;
            Parameters.Remove(param);
            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();

            ClearItemList();
            ClearParamFields();
        }

        private void ParameterType_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
            {
                return;
            }

            if (e.AddedItems[0].ToString() == "Combo")
            {
                ItemListbox.Visibility = Visibility.Visible;
                Item1.Visibility = Visibility.Visible;
                Item2.Visibility = Visibility.Visible;
                Item3.Visibility = Visibility.Visible;
                Item4.Visibility = Visibility.Visible;
            }
            else
            {
                ItemListbox.Visibility = Visibility.Collapsed;
                Item1.Visibility = Visibility.Collapsed;
                Item2.Visibility = Visibility.Collapsed;
                Item3.Visibility = Visibility.Collapsed;
                Item4.Visibility = Visibility.Collapsed;
            }
        }

        private void EditParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (ParameterListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Parameter Selected"));
                return;
            }

            var param = (AceParameter)ParameterListBox.SelectedItem;

            ParameterID.Text = param.ID;
            ParameterName.Text = param.Name;
            ParameterDesc.Text = param.Description;
            ParameterInitVal.Text = param.InitalValue;
            ParameterType.Text = param.Type;

            Items = param.ItemsNames;
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        private void AddItem_OnClick(object sender, RoutedEventArgs e)
        {
            var key = ItemKey.Text;
            var value = ItemValue.Text;

            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Invalid Item Key/Value"));
                return;
            }

            Items.Add(key, value);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();

            ClearItemFields();
        }

        private void RemoveItem_OnClick(object sender, RoutedEventArgs e)
        {
            if (ItemListbox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Item Selected"));
                return;
            }

            var item = (KeyValuePair<string, string>)ItemListbox.SelectedItem;
            Items.Remove(item.Key);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        private void ClearInputFields()
        {
            ConditionName.Text = string.Empty;
            ConditionID.Text = string.Empty;
            CategoryID.Text = string.Empty;
            CategoryName.Text = string.Empty;
            ScriptName.Text = string.Empty;
            DisplayText.Text = string.Empty;
            Description.Text = string.Empty;
            HighlightCheck.IsChecked = false;
            IsDeprecatedCheck.IsChecked = false;
            IsCompatibleWithTriggers.IsChecked = false;
            IsInvertible.IsChecked = false;
            IsFakeTriggerCheck.IsChecked = false;
            IsLoopingCheck.IsChecked = false;
            IsStaticCheck.IsChecked = false;
            IsTriggertCheck.IsChecked = false;

            ClearParamFields();
        }


        private void ClearParamFields()
        {
            ParameterID.Text = string.Empty;
            ParameterName.Text = string.Empty;
            ParameterDesc.Text = string.Empty;
            ParameterInitVal.Text = string.Empty;
            ParameterType.Text = string.Empty;

            ClearItemFields();
        }

        private void ClearItemFields()
        {
            ItemKey.Text = string.Empty;
            ItemValue.Text = string.Empty;
        }

        public void ClearParameterList()
        {
            Parameters = new ObservableCollection<AceParameter>();
            ParameterListBox.ItemsSource = null;
            ParameterListBox.Items.Refresh();
        }

        public void ClearItemList()
        {
            Items = new Dictionary<string, string>();
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

    }
}
