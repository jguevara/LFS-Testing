﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Actions : AceBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        //The name of the function in the runtime script for this ACE
        public string ScriptName { get; set; }
        //Set to true to deprecate the ACE. This hides it in the editor, but allows existing projects to continue using it.
        public bool IsDeprecated { get; set; }
        //Set to true to highlight the ACE in the condition/action/expression picker dialogs. This should only be used
        //for the most regularly used ACEs, to help users pick them out from the list easily.
        public bool Highlight { get; set; }
        //An array of parameter definitions. See the section below on parameters. This can be omitted if the ACE does not use any parameters.
        public List<AceParameter> Parameters { get; set; }

        //the name that appears in the condition/action picker dialog.
        public string ListName { get; set; }
        //he text that appears in the event sheet. You can use simple BBCode tags like [b] and [i], and use {0}, {1} etc. as parameter placeholders.
        //(There must be one parameter placeholder per parameter.) For behaviors only, the placeholder {my} is substituted for the behavior name and icon.
        public string DisplayText { get; set; }
        //a description of the action or condition, which appears as a tip at the top of the condition/action picker dialog.
        public string Description { get; set; }

        public Actions()
        {
            Parameters = new List<AceParameter>();
        }

        public override bool Equals(object obj)
        {
            try
            {
                return this.ID == ((Actions)obj)?.ID;
            }
            catch
            {
                return false;
            }

        }

        public override int GetHashCode()
        {
            return this.ID.GetHashCode();
        }

    }
}
