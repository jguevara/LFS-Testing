﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class Condition : AceBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        //The name of the function in the runtime script for this ACE
        public string ScriptName { get; set; }
        //Set to true to deprecate the ACE.This hides it in the editor, but allows existing projects to continue using it.
        public bool IsDeprecated { get; set; }
        //Set to true to highlight the ACE in the condition/action/expression picker dialogs. This should only be used
        //for the most regularly used ACEs, to help users pick them out from the list easily.
        public bool Highlight { get; set; }
        //An array of parameter definitions. See the section below on parameters. This can be omitted if the ACE does not use any parameters.
        public List<AceParameter> Parameters { get; set; }
        //Specifies a trigger condition. This appears with an arrow in the event sheet. Instead of being evaluated every tick, 
        //triggers only run when they are explicity triggered by a runtime call.
        public bool IsTrigger { get; set; }
        //Specifies a fake trigger. This appears identical to a trigger in the event sheet, but is actually evaluated every tick. 
        //This is useful for conditions which are true for a single tick, such as for APIs which must poll a value every tick.
        public bool IsFakeTrigger { get; set; }
        //Normally, the condition runtime method is executed once per picked instance. If the condition is marked static, 
        //the runtime method is executed once only, on the object type class. This means the runtime method must also 
        //implement the instance picking entirely itself, including respecting negation and OR blocks.
        public bool IsStatic { get; set; }
        //Display an icon in the event sheet to indicate the condition loops. This should only be used with conditions which implement re-triggering.
        public bool IsLooping { get; set; }
        //Allow the condition to be inverted in the event sheet. Set to false to disable invert.
        public bool IsInvertible { get; set; }
        //Allow the condition to be used in the same branch as a trigger.Set to false if the condition does not make sense when used in a trigger, 
        //such as the Trigger once condition.
        public bool IsCompatibleWithTriggers { get; set; }

        //the name that appears in the condition/action picker dialog.
        public string ListName { get; set; }
        //he text that appears in the event sheet. You can use simple BBCode tags like [b] and [i], and use {0}, {1} etc. as parameter placeholders.
        //(There must be one parameter placeholder per parameter.) For behaviors only, the placeholder {my} is substituted for the behavior name and icon.
        public string DisplayText { get; set; }
        //a description of the action or condition, which appears as a tip at the top of the condition/action picker dialog.
        public string Description { get; set; }

        public Condition()
        {
            Parameters = new List<AceParameter>();
        }

        public override bool Equals(object obj)
        {
            try
            {
                return this.ID == ((Condition)obj)?.ID;
            }
            catch
            {
                return false;
            }

        }

        public override int GetHashCode()
        {
            return this.ID.GetHashCode();
        }
    }
}
