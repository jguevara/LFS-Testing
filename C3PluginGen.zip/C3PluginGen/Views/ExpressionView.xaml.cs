﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;
using Expression = C3PluginGen.Models.Expression;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for ExpressionView.xaml
    /// </summary>
    public partial class ExpressionView : UserControl
    {
        public ObservableCollection<Expression> Expressions { get; set; }
        public ObservableCollection<AceParameter> Parameters { get; set; }
        public Dictionary<string, string> Items { get; set; }

        public ExpressionView()
        {
            Expressions = new ObservableCollection<Expression>();
            Items = new Dictionary<string, string>();
            Parameters = new ObservableCollection<AceParameter>();

            InitializeComponent();
            DataContext = this;

            FieldInfo[] types = typeof(AceParameterType).GetFields();
            ParameterType.ItemsSource = types.Select(x => x.Name);
            ParameterType.SelectedIndex = 0;

            types = typeof(ExpressionReturnType).GetFields();
            ReturnType.ItemsSource = types.Select(x => x.Name);
            ReturnType.SelectedIndex = 0;
        }

        private void DeleteExpressionButton_Click(object sender, RoutedEventArgs e)
        {
            if (ExpressionListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Expression Selected"));
                return;
            }

            var expression = (Expression)ExpressionListBox.SelectedItem;
            Expressions.Remove(expression);

            ClearItemList();
            ClearParameterList();
            ClearInputFields();
        }

        private void EditExpressionButton_Click(object sender, RoutedEventArgs e)
        {
            if (ExpressionListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Expression Selected"));
                return;
            }

            var expression = (Expression)ExpressionListBox.SelectedItem;

            ExpressionName.Text = expression.Name;
            ExpressionID.Text = expression.ID;
            CategoryID.Text = expression.CategoryID;
            CategoryName.Text = expression.CategoryName;
            ReturnType.Text = expression.ReturnType;
            TranslatedName.Text = expression.TranslatedName;
            Description.Text = expression.Description;
            HighlightCheck.IsChecked = expression.Highlight;
            IsDeprecatedCheck.IsChecked = expression.IsDeprecated;
            IsVariadicParametersCheck.IsChecked = expression.IsVariadicParameters;

            Parameters = new ObservableCollection<AceParameter>(expression.Parameters);
            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();
        }

        private void AddExpressionButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ExpressionID.Text))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Ivalid Expression ID"));
                return;
            }

            var highlight = HighlightCheck.IsChecked != null && (HighlightCheck.IsChecked.Value);
            var deprecated = IsDeprecatedCheck.IsChecked != null && (IsDeprecatedCheck.IsChecked.Value);
            var varadicParam = IsVariadicParametersCheck.IsChecked != null && (IsVariadicParametersCheck.IsChecked.Value);

            var expression = new Expression
            {
                Name = ExpressionName.Text,
                ID = ExpressionID.Text,
                ExpressionName = ExpressionName.Text,
                CategoryID = CategoryID.Text,
                CategoryName = CategoryName.Text,
                ReturnType = ReturnType.Text,
                TranslatedName = TranslatedName.Text,
                Description = Description.Text,
                Highlight = highlight,
                IsDeprecated = deprecated,
                IsVariadicParameters = varadicParam,
                Parameters = Parameters.ToList()
            };

            Expressions.Remove(expression);
            Expressions.Add(expression);

            ClearItemList();
            ClearParameterList();
            ClearInputFields();
        }

        private void AddParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ParameterID.Text))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Invalid Parameter ID"));
                return;
            }

            var param = new AceParameter
            {
                ID = ParameterID.Text,
                Name = ParameterName.Text,
                Description = ParameterDesc.Text,
                InitalValue = ParameterInitVal.Text,
                Type = ParameterType.Text,
                ItemsNames = Items
            };

            Parameters.Remove(param);
            Parameters.Add(param);

            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();

            ClearItemList();
            ClearParamFields();
        }

        private void RemoveParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (ParameterListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Parameter Selected"));
                return;
            }

            var param = (AceParameter)ParameterListBox.SelectedItem;
            Parameters.Remove(param);
            ParameterListBox.ItemsSource = Parameters;
            ParameterListBox.Items.Refresh();

            ClearItemList();
            ClearParamFields();
        }

        private void EditParameterButton_Click(object sender, RoutedEventArgs e)
        {
            if (ParameterListBox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Parameter Selected"));
                return;
            }

            var param = (AceParameter)ParameterListBox.SelectedItem;

            ParameterID.Text = param.ID;
            ParameterName.Text = param.Name;
            ParameterDesc.Text = param.Description;
            ParameterInitVal.Text = param.InitalValue;
            ParameterType.Text = param.Type;

            Items = param.ItemsNames;
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        private void ParameterType_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
            {
                return;
            }

            if (e.AddedItems[0].ToString() == "Combo")
            {
                ItemListbox.Visibility = Visibility.Visible;
                Item1.Visibility = Visibility.Visible;
                Item2.Visibility = Visibility.Visible;
                Item3.Visibility = Visibility.Visible;
                Item4.Visibility = Visibility.Visible;
            }
            else
            {
                ItemListbox.Visibility = Visibility.Collapsed;
                Item1.Visibility = Visibility.Collapsed;
                Item2.Visibility = Visibility.Collapsed;
                Item3.Visibility = Visibility.Collapsed;
                Item4.Visibility = Visibility.Collapsed;
            }
        }

        private void AddItem_OnClick(object sender, RoutedEventArgs e)
        {
            var key = ItemKey.Text;
            var value = ItemValue.Text;

            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Invalid Item Key/Value"));
                return;
            }

            Items.Add(key, value);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();

            ClearItemFields();
        }

        private void RemoveItem_OnClick(object sender, RoutedEventArgs e)
        {
            if (ItemListbox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Item Selected"));
                return;
            }

            var item = (KeyValuePair<string, string>)ItemListbox.SelectedItem;
            Items.Remove(item.Key);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        public void ClearInputFields()
        {
            ExpressionName.Text = string.Empty;
            ExpressionID.Text = string.Empty;
            CategoryID.Text = string.Empty;
            CategoryName.Text = string.Empty;
            TranslatedName.Text = string.Empty;
            Description.Text = string.Empty;
            ReturnType.SelectedIndex = 0;
            HighlightCheck.IsChecked = false;
            IsDeprecatedCheck.IsChecked = false;
            IsVariadicParametersCheck.IsChecked = false;

            ClearParamFields();
        }

        public void ClearParamFields()
        {
            ParameterID.Text = string.Empty;
            ParameterName.Text = string.Empty;
            ParameterDesc.Text = string.Empty;
            ParameterInitVal.Text = string.Empty;
            ParameterType.Text = string.Empty;

            ClearItemFields();
        }

        public void ClearItemFields()
        {
            ItemKey.Text = string.Empty;
            ItemValue.Text = string.Empty;
        }

        public void ClearParameterList()
        {
            Parameters = new ObservableCollection<AceParameter>();
            ParameterListBox.ItemsSource = null;
            ParameterListBox.Items.Refresh();
        }

        public void ClearItemList()
        {
            Items = new Dictionary<string, string>();
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }
    }
}
