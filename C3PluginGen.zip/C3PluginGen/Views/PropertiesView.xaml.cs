﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using C3PluginGen.Framework;
using C3PluginGen.Models;

namespace C3PluginGen.Views
{
    /// <summary>
    /// Interaction logic for PropertiesView.xaml
    /// </summary>
    public partial class PropertiesView : UserControl
    {
        public ObservableCollection<PluginProperty> Properties { get; set; }
        public Dictionary<string, string> Items { get; set; }

        public PropertiesView()
        {
            Properties = new ObservableCollection<PluginProperty>();
            Items = new Dictionary<string, string>();

            InitializeComponent();
            DataContext = this;

            FieldInfo[] properties = typeof(PluginPropertyType).GetFields();
            PropertyType.ItemsSource =  properties.Select(x => x.Name);
            PropertyType.SelectedIndex = 0;

            properties = typeof(CallbackType).GetFields();
            LinkCallbackType.ItemsSource = properties.Select(x => x.Name);
            LinkCallbackType.SelectedIndex = 0;
        }

        private void PropertyType_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
            {
                return;
            }

            switch (e.AddedItems[0].ToString())
            {
                case "Combo":
                    LinkText.Visibility = Visibility.Collapsed;
                    LinkCalllbackText.Visibility = Visibility.Collapsed;
                    LinkCallbackType.Visibility = Visibility.Collapsed;
                    LinkTextLbl.Visibility = Visibility.Collapsed;
                    LinkCalllbackTextLbl.Visibility = Visibility.Collapsed;
                    LinkCallbackTypeLbl.Visibility = Visibility.Collapsed;

                    Item1.Visibility = Visibility.Visible;
                    Item2.Visibility = Visibility.Visible;
                    Item3.Visibility = Visibility.Visible;
                    ItemKey.Visibility = Visibility.Visible;
                    ItemListbox.Visibility = Visibility.Visible;
                    ItemValue.Visibility = Visibility.Visible;
                    AddItem.Visibility = Visibility.Visible;
                    RemoveItem.Visibility = Visibility.Visible;
                    break;
                case "Link":
                    LinkText.Visibility = Visibility.Visible;
                    LinkCalllbackText.Visibility = Visibility.Visible;
                    LinkCallbackType.Visibility = Visibility.Visible;
                    LinkTextLbl.Visibility = Visibility.Visible;
                    LinkCalllbackTextLbl.Visibility = Visibility.Visible;
                    LinkCallbackTypeLbl.Visibility = Visibility.Visible;

                    Item1.Visibility = Visibility.Collapsed;
                    Item2.Visibility = Visibility.Collapsed;
                    Item3.Visibility = Visibility.Collapsed;
                    ItemKey.Visibility = Visibility.Collapsed;
                    ItemListbox.Visibility = Visibility.Collapsed;
                    ItemValue.Visibility = Visibility.Collapsed;
                    AddItem.Visibility = Visibility.Collapsed;
                    RemoveItem.Visibility = Visibility.Collapsed;
                    break;
                default:
                    LinkText.Visibility = Visibility.Collapsed;
                    LinkCalllbackText.Visibility = Visibility.Collapsed;
                    LinkCallbackType.Visibility = Visibility.Collapsed;
                    LinkTextLbl.Visibility = Visibility.Collapsed;
                    LinkCalllbackTextLbl.Visibility = Visibility.Collapsed;
                    LinkCallbackTypeLbl.Visibility = Visibility.Collapsed;


                    Item1.Visibility = Visibility.Collapsed;
                    Item2.Visibility = Visibility.Collapsed;
                    Item3.Visibility = Visibility.Collapsed;
                    ItemKey.Visibility = Visibility.Collapsed;
                    ItemListbox.Visibility = Visibility.Collapsed;
                    ItemValue.Visibility = Visibility.Collapsed;
                    AddItem.Visibility = Visibility.Collapsed;
                    RemoveItem.Visibility = Visibility.Collapsed;
                    break;
            }
        }

        private void AddPropertyButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(PropertyID.Text))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Ivalid Property ID"));
                return;
            }

            var prop = new PluginProperty
            {
                Name = PropertyName.Text,
                PropertyId = PropertyID.Text,
                Description = Description.Text,
                Type = PropertyType.Text,
            };

            if (!string.IsNullOrEmpty(InitialValueText.Text))
                prop.WithOption(PluginPropertyOptionType.InitialValue, InitialValueText.Text);

            if (!string.IsNullOrEmpty(MinValueText.Text))
                prop.WithOption(PluginPropertyOptionType.MinValue, MinValueText.Text);

            if (!string.IsNullOrEmpty(MaxValueText.Text))
                prop.WithOption(PluginPropertyOptionType.MaxValue, MaxValueText.Text);

            if (!string.IsNullOrEmpty(DragSpeedMultiplierText.Text))
                prop.WithOption(PluginPropertyOptionType.DragSpeedMultiplier, DragSpeedMultiplierText.Text);

            if (!string.IsNullOrEmpty(LinkText.Text))
                prop.LinkText = LinkText.Text;

            if (!string.IsNullOrEmpty(LinkCallbackType.Text))
                prop.WithOption(PluginPropertyOptionType.CallbackType, LinkCallbackType.Text);

            if (!string.IsNullOrEmpty(LinkCalllbackText.Text))
                prop.WithOption(PluginPropertyOptionType.LinkCallback, LinkCalllbackText.Text);

            foreach (var item in Items)
            {
                prop.WithItem(item.Key, item.Value);
            }

            prop.WithOption("items", string.Join(",", string.Join(",", prop.ItemsNames.Keys.Select(x => $"\"{x}\""))));

            //ensure no duplicates
            Properties.Remove(prop);
            Properties.Add(prop);

            ClearInputsFields();
        }

        private void DeletePropertyButton_Click(object sender, RoutedEventArgs e)
        {
            if (PropertyList.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Property Selected"));
                return;
            }

            var prop = (PluginProperty)PropertyList.SelectedItem;
            Properties.Remove(prop);

            Items = new Dictionary<string, string>();
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();

            ClearInputsFields();
        }

        private void EditPropertyButton_Click(object sender, RoutedEventArgs e)
        {
            if (PropertyList.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Property Selected"));
                return;
            }

            var prop = (PluginProperty) PropertyList.SelectedItem;

            PropertyID.Text = prop.PropertyId;
            PropertyName.Text = prop.Name;
            Description.Text = prop.Description;
            PropertyType.Text = prop.Type;

            foreach (var opt in prop.Options)
            {
                switch (opt.Type)
                {
                    case "initialValue":
                        InitialValueText.Text = opt.Value;
                        break;
                    case "minValue":
                        MinValueText.Text = opt.Value;
                        break;
                    case "maxValue":
                        MaxValueText.Text = opt.Value;
                        break;
                    case "dragSpeedMultiplier":
                        DragSpeedMultiplierText.Text = opt.Value;
                        break;
                    case "linkCallback":
                        LinkCalllbackText.Text = opt.Value;
                        LinkText.Text = prop.LinkText;
                        break;
                    case "callbackType":
                        LinkCallbackType.Text = opt.Value;
                        break;
                    case "items":
                        ItemListbox.ItemsSource = prop.ItemsNames;
                        Items = prop.ItemsNames;
                        break;
                }
            }
        }

        private void AddItem_OnClick(object sender, RoutedEventArgs e)
        {
            var key = ItemKey.Text;
            var value = ItemValue.Text;

            if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(value))
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "Invalid Item Key/Value"));
                return;
            }

            Items.Add(key, value);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        private void RemoveItem_OnClick(object sender, RoutedEventArgs e)
        {
            if (ItemListbox.SelectedIndex == -1)
            {
                EventBus.Hub.Publish(new ApplicationErrorEvent(this, "No Item Selected"));
                return;
            }

            var item =  (KeyValuePair<string,string>)ItemListbox.SelectedItem;
            Items.Remove(item.Key);
            ItemListbox.ItemsSource = Items;
            ItemListbox.Items.Refresh();
        }

        public void ClearInputsFields()
        {
            PropertyID.Text = string.Empty;
            PropertyName.Text = string.Empty;
            Description.Text = string.Empty;
            PropertyType.SelectedIndex = 0;
            InitialValueText.Text = string.Empty;
            MinValueText.Text = string.Empty;
            MaxValueText.Text = String.Empty;
            DragSpeedMultiplierText.Text = string.Empty;
            LinkText.Text = string.Empty;
            LinkCalllbackText.Text = string.Empty;
            LinkCallbackType.SelectedIndex = 0;
            ItemListbox.Items.Clear();
            ItemKey.Text = string.Empty;
            ItemValue.Text = string.Empty;
        }
    }
}
