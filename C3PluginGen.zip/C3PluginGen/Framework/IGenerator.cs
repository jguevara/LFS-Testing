﻿using C3PluginGen.Models;

namespace C3PluginGen.Framework
{
    public interface IGenerator<T>
    {
        string Generate(T type);
    }
}