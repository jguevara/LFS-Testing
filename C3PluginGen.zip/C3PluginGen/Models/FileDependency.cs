﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C3PluginGen.Models
{
    public class FileDependency : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public string File { get; set; }
        public string Type { get; set; }
    }

    public static class FileType
    {
        public const string InlineScript = "inline-script";
        public const string CopyToOutput = "copy-to-output";
        public const string ExternalCss = "external-css";
        public const string ExternalScript = "external-script";
    }
}
